﻿using System.Collections.Generic;
using NorthwindCustomerApp.DataAccessLayer;

namespace NorthwindCustomerApp.BusinessLayer
{
    public class CustomerBusiness
    {
        private CustomerDataAccess dataAccess;

        public int GetCustomerCount()
        {
            return dataAccess.GetCustomerCount();
        }

        public List<string> GetCustomerNames()
        {
            return dataAccess.GetCustomerNames();
        }

        public List<string> GetCustomerLastNames()
        {
            return dataAccess.GetCustomerLastNames();
        }
    }
}